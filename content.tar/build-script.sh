#!/bin/bash

# 构建脚本：将 .env 文件的内容合并到 manifest.yml 中

echo "正在处理环境变量..."

# 读取 .env 文件并替换 manifest.yml 中的占位符
if [ -f ".env" ]; then
    # 创建备份
    cp manifest.yml manifest.yml.backup
    
    # 使用 envsubst 替换环境变量（需要先导出环境变量）
    set -a  # 自动导出所有变量
    source .env
    set +a  # 停止自动导出
    
    # 替换 manifest.yml 中的环境变量
    envsubst < manifest.yml.backup > manifest.yml.processed
    
    echo "环境变量已处理完成"
    echo "原始文件备份为: manifest.yml.backup"
    echo "处理后文件为: manifest.yml.processed"
else
    echo "错误：找不到 .env 文件"
    exit 1
fi
