#!/bin/bash

echo "检查 Docker 套接字位置..."

# 检查是否使用无根 Docker
if [ -n "$XDG_RUNTIME_DIR" ] && [ -S "$XDG_RUNTIME_DIR/docker.sock" ]; then
    echo "检测到无根 Docker"
    echo "Docker 套接字位置: $XDG_RUNTIME_DIR/docker.sock"
    echo "建议在 .env 文件中设置："
    echo "DOCKER_SOCKET_LOCATION=$XDG_RUNTIME_DIR/docker.sock"
elif [ -S "/var/run/docker.sock" ]; then
    echo "检测到标准 Docker"
    echo "Docker 套接字位置: /var/run/docker.sock"
    echo "当前 .env 配置正确"
else
    echo "未找到 Docker 套接字，请检查 Docker 是否正在运行"
    echo "常见位置："
    echo "- 标准 Docker: /var/run/docker.sock"
    echo "- 无根 Docker: \$XDG_RUNTIME_DIR/docker.sock (通常是 /run/user/\$(id -u)/docker.sock)"
fi

# 检查当前用户的 UID
echo ""
echo "当前用户 UID: $(id -u)"
echo "如果使用无根 Docker，套接字通常位于: /run/user/$(id -u)/docker.sock"

# 检查 Docker 是否以无根模式运行
if docker info 2>/dev/null | grep -q "rootless"; then
    echo ""
    echo "✓ Docker 正在以无根模式运行"
    echo "建议的 DOCKER_SOCKET_LOCATION: /run/user/$(id -u)/docker.sock"
else
    echo ""
    echo "✓ Docker 正在以标准模式运行"
    echo "当前的 DOCKER_SOCKET_LOCATION 配置应该正确"
fi
